namespace Asteroids
{
    internal sealed class Asteroid : Enemy
    {

    }
}

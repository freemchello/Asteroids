using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Asteroids
{
    public class PlayerHealth /*: Unit*/
    {
        float MaxHealth;
        public void Damage()
        {
            
        }
    }
}
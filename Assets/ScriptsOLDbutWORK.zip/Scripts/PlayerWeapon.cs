using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Asteroids
{
    public class PlayerWeapon
    {
        int ammo;
        int minigun;
        int rocket;
    }
}
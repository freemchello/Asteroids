using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Asteroids
{
    public sealed class Rocket : IWeapon
    {
        private readonly Rigidbody2D _prefabRocket;
        private readonly IViewServices _viewServices; //��� ����
        public Rocket(Rigidbody2D prefabRocket, IViewServices viewServices)
        {
            _prefabRocket = prefabRocket;
            _viewServices = viewServices;
        }
        public void Attack()
        {
            var rocket = _viewServices.Instantiate<Rigidbody2D>(_prefabRocket.gameObject);
            rocket.AddForce(Vector2.up);
            _viewServices.Destroy(rocket.gameObject);
        }
    }
}
namespace Asteroids
{
    interface IWeapon
    {
        void Attack();
    }
}
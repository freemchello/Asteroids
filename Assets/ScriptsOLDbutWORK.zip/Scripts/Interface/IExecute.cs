namespace Asteroids
{
    public interface IExecute
    {
        void Update();
    }
}